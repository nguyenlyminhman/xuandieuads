<?php $__env->startSection('content'); ?>
<!-- /.row -->
<br>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3>Danh Sách Bài Viết</h3>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTablesPost">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tiêu Đề</th>
                            <th>Tóm Tắt</th>
                            <th>Hình</th>
                            <th>Mục Chính</th>
                            <th>Mục Phụ</th>
                            <th>Online</th>
                            <th>Nổi Bật</th>
                            <th>Tùy Chọn</th>  
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="even gradeA">
                                <td><?php echo e($pt->id); ?></td>
                                <td><?php echo e($pt->title); ?></td>
                                <td><p><?php echo e($pt->short_content); ?></p></td>
                                <td>
                                    <img src="upload/image/<?php echo e($pt->image); ?>" class="img-rounded" width="100px" height="75px" />
                                </td>
                                <td><?php echo e($pt->subCategory->mainCategory->main_cate_name); ?></td>
                                <td><?php echo e($pt->subCategory->sub_cate_name); ?></td>
                                <td><?php echo e($pt->online == 0 ? 'Có' : 'Không'); ?></td>
                                <td><?php echo e($pt->high_light == 0 ? "Có" : "Không"); ?></td>
                                <td>
                                
                                    <a href="admin/post/edit/<?php echo e($pt->id); ?>" type="button" class="btn btn-warning">Sửa</a><br><br>
                                    <?php if($pt->main_cate_status== 0): ?>
                                        <a  href="admin/post/delete/<?php echo e($pt->id); ?>" type="button" class="btn btn-danger" 
                                            onclick='return confirm("Lưu Ý: Sau khi xóa dữ liệu liên quan cũng sẽ mất.\n           Có chắc muốn xóa dòng này?");'>
                                            Xóa
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!--end-danh sach menu chinh-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>