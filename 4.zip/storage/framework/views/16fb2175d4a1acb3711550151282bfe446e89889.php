<!-- begin-tab-hightlight -->
        <div class="col-sm-4">
            <div class="tab tab-sale">
                <button class="tabsale" onclick="openSale(event, 'Hot')" id="defaultSale"><h4> Khuyến Mãi Hot &nbsp;</h4></button>
                <button class="tabsale" onclick="openSale(event, 'Online')"><h4>Chuyên Mục Chính</h4></button>
            </div>
            <div id="Hot" class="tabsalecontent">
                <?php $__currentLoopData = $mmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $data = $hot->post->where('high_light',0)->sortByDesc('created_at')->take(10) ?>
                    <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="media">
                                <a href="chi-tiet-khuyen-mai/<?php echo e($ht->id); ?>/<?php echo e($ht->title_seolink); ?>.html">
                                    <div class="media-left media-top">
                                        <img src="public/upload/image/<?php echo e($ht->image); ?>" class="media-object"  height="75px" width="100px">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo e($ht->title); ?></h4>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            <div id="Online" class="tabsalecontent">
            <?php $__currentLoopData = $mmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mmnu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="list-group" style="border: none">
                    <?php if(count($mmnu->subCategory) > 0 ): ?>
                        <li class="list-group-item" style="border: none"> 
                            <div class="media">
                                <div class="media-left media-top">
                                    <img src="public/images/promotion.png" class="media-object">
                                </div>
                                <div class="media-body">
                                    <h4><?php echo e($mmnu->main_cate_name); ?></h4>
                                </div>
                            </div>
                        </li>
                        <ul style="border: none">
                            <?php $__currentLoopData = $mmnu->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smnu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item" style="border: none"> 
                                        <a href="<?php echo e($mmnu->id == 1 ? 'tin-khuyen-mai' : 'ma-giam-gia-voucher'); ?>/<?php echo e($smnu->id); ?>/<?php echo e($smnu->sub_cate_seolink); ?>.html" class="list-group-item" style="text-decoration: none">
                                            <div class="media">
                                                <div class="media-left media-top">
                                                    <img src="public/images/promotion.png" class="media-object">
                                                </div>
                                                <div class="media-body">
                                                        <h4><?php echo e($smnu->sub_cate_name); ?></h4>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
<!--end-tab-hightlight -->
<!--interesting-ads-->
        <br>
        <div class="panel panel-danger ">
            <div class="panel-heading panel-heading-interesting text-center">
                <h4>Mua Online</h4>
            </div>
            <?php $__currentLoopData = $mmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $data = $onl->post->where('online',0)->sortByDesc('created_at')->take(15) ?>
                <?php $__currentLoopData = $data->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $online): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="interesting-ads">
                        <div class="row">
                            <div class="media">
                                <a href="chi-tiet-khuyen-mai/<?php echo e($online->id); ?>/<?php echo e($online->title_seolink); ?>.html">
                                    <div class="media-left media-top">
                                        <img src="public/upload/image/<?php echo e($online->image); ?>" class="media-object" height="75px" width="100px">
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading"><?php echo e($online->title); ?></h4>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
<!--end-interesting-ads-->
