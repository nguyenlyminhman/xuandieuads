<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="panel panel-primary">
        <div class="panel-heading text-center">
            Thêm Menu Chính
        </div>
        <form action="admin/main-menu/get-main-menu-list" method="POTS">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="form-group">
                <label for="email">Tên Menu:</label>
                <input type="text" class="form-control" id="cateName" name="catename" placeHolder="Nhập tên menu chính" required>
            </div>
            <button type="submit" class="btn btn-default">Thêm</button>
            <button type="reset" class="btn btn-default">Đặt Lại</button>
            <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#addMenu">Ẩn Panel</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>