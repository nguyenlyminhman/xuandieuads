<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Begin-new-voucher-->
<div class="container ">
    <div class="row">
        <div class="col-sm-8">
            <div class=" row text-left">
                <div class="col-sm-12">
                    <h3>Tìm kiếm: <?php echo e($tukhoa); ?></h3>
                </div>
            </div>
            <hr>
            <?php $i = 0 ?>
            <?php $__currentLoopData = $tinkhuyenmai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i++; ?>
                <div class="row">
                    <div class="col-sm-3">
                        <img src="public/upload/image/<?php echo e($gg->image); ?>" height="125px" width="170px">
                    </div>
                    <div class="col-sm-9">
                        <div class="row voucher-title">
                            <p> <a href="chi-tiet-khuyen-mai/<?php echo e($gg->id); ?>/<?php echo e($gg->title_seolink); ?>.html"><?php echo e($gg->title); ?></a></p>
                        </div>
                        
                        <div class="row voucher-content">
                            <p> <span class="text-primary text"><span class="glyphicon glyphicon-hand-right"></span></span>
                                <?php echo e($gg->short_content); ?> </p>
                        </div>
                        <div class="row">
                            <a target="_blank" href="<?php echo e($gg->link_to); ?>" type="button" class="btn btn-default">
                                <span class="glyphicon glyphicon-hand-right"> </span>
                                    Đến trang khuyến mãi
                                <span class="glyphicon glyphicon-hand-right"> </span>
                            </a>
                        </div> 
                    </div>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            
                <div class="row text-center">
                    <?php echo e($tinkhuyenmai->links()); ?>

                </div>
            
        </div>

        <?php echo $__env->make('layout.menuphai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
    </div>
</div>
<!--End new voucher-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>