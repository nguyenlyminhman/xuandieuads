    <hr>
    <h2>Có thể bạn quan tâm</h2>
    <hr>
    <?php $i = 0 ?>
        <div class="row">
            <?php $__currentLoopData = $quantam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4" style="float: left">
                    <img src="public/upload/image/<?php echo e($qt->image); ?>" height="150px" width="250px">
                    <div class="text-center voucher-title">
                        <p> 
                            <a href="chi-tiet-khuyen-mai/<?php echo e($qt->id); ?>/<?php echo e($qt->title_seolink); ?>.html">
                                <?php echo e($qt->title); ?>

                            </a>
                        </p>
                    </div>
                    
                </div>
                <?php $i++; ?>
                <?php if($i%3==0): ?>
                    </div><br><div class="row">
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
    