<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layout.bigsale', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--Begin-new-voucher-->
<div class="container ">
    <div class="row">
        <div class="col-sm-8">
            <?php $__currentLoopData = $khuyenmai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-sm-3">
                        <img src="public/upload/image/<?php echo e($home->image); ?>" height="125px" width="170px">
                    </div>
                    <div class="col-sm-9">
                        <div class="row voucher-title">
                            <p><a href="chi-tiet-khuyen-mai/<?php echo e($home->id); ?>/<?php echo e($home->title_seolink); ?>.html"><?php echo e($home->title); ?></a></p>
                        </div>
                        <div class="row voucher-content">
                            <p><span class="text-primary text"><span class="glyphicon glyphicon-hand-right"></span></span>
                                <?php echo e($home->short_content); ?> 
                            </p>
                        </div>
                        <div class="row">
                            <a target="_blank" href="chi-tiet-khuyen-mai/<?php echo e($home->id); ?>/<?php echo e($home->title_seolink); ?>.html" type="button" class="btn btn-default">
                                Xem thêm
                            </a>
                        </div> 
                    </div>
                </div>
                <hr>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="row text-center">
                 <?php echo e($khuyenmai->links()); ?>

            </div>
            
        </div>
            <?php echo $__env->make('layout.menuphai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<!--End new voucher-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>