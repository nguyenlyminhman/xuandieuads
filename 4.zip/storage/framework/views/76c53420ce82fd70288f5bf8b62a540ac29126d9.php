<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login - Xuân Diệu Ads</title>
	<base href="<?php echo e(asset('')); ?>">
    <!-- Bootstrap Core CSS -->
    <link href="./public/admin_asset/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="./public/admin_asset/dist/css/sb-admin-2.css" rel="stylesheet">
	<link href="./public/admin_asset/vendor/login/login.css" rel="stylesheet">
</head>
<body>
<div class="container">
 <div class="row">
	<div class="panel panel-default">
		<div class="panel-heading text-center">
			<h2 class="form-signin-heading">Welcome to XuanDieuAds</h2>
		</div>
			<?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(session('notification')): ?>
                <div class="alert alert-success">
                        <?php echo e(session('notification')); ?> <br>
                </div>
            <?php endif; ?>

		<div class="panel panel-body">
			<form class="form-signin" action="admin/login" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
				<div class="form-group">
					<label for="inputEmail" class="sr-only"></label>
					<input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
				</div>
				<div class="form-group">
					<label for="inputPassword" class="sr-only"></label>
					<input type="password" name="password" id="inputPassword" class="form-control" placeholder="Password" required>
				</div>
				<button class="btn btn-lg btn-primary btn-block" type="submit">Sign In</button>
			</form>
		</div>
	</div>
	</div>
</div> <!-- /container -->
    <!-- jQuery -->
    <script src="./public/admin_asset/vendor/jquery/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="./public/admin_asset/vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
