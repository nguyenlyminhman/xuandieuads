<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Begin-new-voucher-->
<div class="container ">
    <div class="row">
        <div class="col-sm-8">
           <p> 
           <?php echo $chitietkhuyenmai->full_content; ?>

           </p>
           <?php echo $__env->make('pages.quantam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <?php echo $__env->make('layout.menuphai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<!--End new voucher-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>