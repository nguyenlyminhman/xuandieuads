<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                <h2>Thay Đổi Mật Khẩu</h2>
            </header>
            
            <div class="col-lg-6">
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($err); ?> <br >
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(session('notification')): ?>
                    <div class="alert alert-success">
                            <?php echo e(session('notification')); ?> <br>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="clearfix"> </div>
            <div class="panel-body">
                <div class="position-center col-lg-6">
                    <form action="admin/user/update-pass/<?php echo e($user->id); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <div class="form-group">
                        <label for="email">Mật Khẩu Mới:</label>
                        <input type="password" class="form-control" id="password" name="password" placeHolder="Nhập mật khẩu" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Xác Nhận Mật Khẩu:</label>
                        <input type="password" class="form-control" id="confirm_password" name="repassword" placeHolder="Xác nhận mật khẩu" required />
                    </div>
                        <button type="submit" class="btn btn-default">Cập Nhật</button>
                    </form>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var password = document.getElementById("password") , confirm_password = document.getElementById("confirm_password");

    function validatePassword(){
        if(password.value != confirm_password.value) {
            confirm_password.setCustomValidity("Passwords không trùng.");
        } else {
            confirm_password.setCustomValidity('');
        }
    }
    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>