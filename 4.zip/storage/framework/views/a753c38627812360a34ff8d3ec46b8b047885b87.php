<?php $__env->startSection('content'); ?>
<!-- /.row -->
<br>
<div class="row">
    <div class="col-lg-12">
        <!--begin add and edit button-->
        <div class="col-lg-3">
            <button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#addMenu">Thêm Người Dùng</button>
        </div>
        <!--end of add and edit button-->
        <!--begin notification errors-->
        <div class="col-lg-6">
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(session('notification')): ?>
                <div class="alert alert-success">
                        <?php echo e(session('notification')); ?> <br>
                </div>
            <?php endif; ?>
        </div>
        <!--end of notification errors-->
    </div>
    <div class="col-lg-12">
        <!--add new menu item-->
        <div id="addMenu" class="collapse col-lg-6">
            <br />
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    Thêm Người Dùng
                </div>
                <form action="admin/user/get-all-user" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="form-group">
                        <label for="email">Tên:</label>
                        <input type="text" class="form-control" name="name" placeHolder="Nhập tên người dùng" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" name="email" placeHolder="qwerty@asd.vn" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Mật Khẩu:</label>
                        <input type="password" class="form-control" id="password" name="password" placeHolder="Nhập mật khẩu" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Xác Nhận Mật Khẩu:</label>
                        <input type="password" class="form-control" id="confirm_password" name="repassword" placeHolder="Xác nhận mật khẩu" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Quyền:</label><br>
                        <label class="radio-inline"><input value="0" type="radio" name="level" >Admin</label>
                        <label class="radio-inline"><input value="1" type="radio" name="level" checked>Thường</label>
                    </div>
                    <button type="submit" class="btn btn-default">Thêm</button>
                    <button type="reset" class="btn btn-default">Đặt Lại</button>
                    <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#addMenu">Ẩn Hộp Thoại</button>
                </form>
                <br>
            </div>
        </div>
        <!--end add new menu item-->
    </div>
    <!--danh sach menu chinh-->
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h3>Danh Sách Menu Chính </h3>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover"  id="dataTables-example">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên</th>
                                <th>Quyền Truy Cập</th>
                                <th>Email</th>
                                <th>Ngày Tạo</th>
                                <th>Lần Cập Nhật Cuối</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ur->id); ?></td>
                                <td><?php echo e($ur->name); ?></td>
                                <td><?php echo e($ur->level==0 ? "Admin":"Thường"); ?></td>
                                <td><?php echo e($ur->email); ?></td>
                                <td><?php echo e(date("d/m/Y", strtotime($ur->created_at))); ?></td>
                                <td><?php echo e(date("d/m/Y", strtotime($ur->updated_at))); ?></td>
                                 
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!--end-danh sach menu chinh-->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var password = document.getElementById("password") , confirm_password = document.getElementById("confirm_password");

    function validatePassword(){
        if(password.value != confirm_password.value) {
            confirm_password.setCustomValidity("Passwords không trùng.");
        } else {
            confirm_password.setCustomValidity('');
        }
    }
    password.onchange = validatePassword;
    confirm_password.onkeyup = validatePassword;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>