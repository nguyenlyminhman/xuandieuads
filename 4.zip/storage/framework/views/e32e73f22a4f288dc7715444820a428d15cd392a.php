<!-- Begin-MyStore -->
<div class="container text-center giakhang_container">
        <?php $i = 0?>
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giakhang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($giakhang->categoryImage->id == 4): ?>
                    <h3><?php echo e($giakhang->categoryImage->name); ?></h3>
                <?php $i++ ?>
                <?php endif; ?>
                <?php if($i == 1): ?>
                    <?php break; ?>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <div class="row center giakhang_row">
            <?php $i = 0?>
            <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giakhang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($giakhang->categoryImage->id == 4): ?>
                    <div class="col-sm-2 center giakhang_col">
                        <a target="_blank" href="<?php echo e($giakhang->link_to); ?>">
                            <img src="public/images/new.png" class="img-responsive center-block">
                            <img src="public/upload/image/<?php echo e($giakhang->img_name); ?>" class="img-responsive center-block" height="100px" width="150px" alt="Image">
                        <p> <?php echo e($giakhang->title); ?>  </p></a>
                    </div>
                    <?php $i++ ?>
                <?php endif; ?>
                <?php if($i == 6): ?>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <br>
<!--end MyStore -->
