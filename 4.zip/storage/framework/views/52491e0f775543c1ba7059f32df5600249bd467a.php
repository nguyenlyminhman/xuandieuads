<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
        
            <header class="panel-heading">
            <?php if($post->subCategory->mainCategory->id==2): ?>
                <h2>Chỉnh Sửa Mã Giảm Giá</h2>
            <?php else: ?>
                <h2>Chỉnh Sửa Tin Khuyễn Mãi</h2>
            <?php endif; ?>
            </header>
        
            <div class="panel-body">

                <div class="position-center">
                            <?php if(count($errors)>0): ?>
                                <div class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($err); ?> <br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <?php if(session('notification')): ?>
                                <div class="alert alert-success">
                                        <?php echo e(session('notification')); ?> <br> <a href="admin/post/get-all-post" class="btn btn-default">Quay Lại</a>
                                </div>
                            <?php endif; ?>
                </div>
                <div class="position-center">
                <?php if($post->subCategory->mainCategory->id==2): ?>
                
                    <form role="form" action="admin/post/edit-discount/<?php echo e($post->id); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <div class="form-group">
                            <label for="exampleInputEmail1">Chuyên Mục Phụ:</label>
                            <select name="subcategory" id="subcategory" class="form-control selectpicker" required>
                               <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option 
                                    <?php if( $post->fk_idSubCategory == $smenu->id): ?>
                                        <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    value="<?php echo e($smenu->id); ?>"><?php echo e($smenu->sub_cate_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tiêu Đề:</label>
                            <input type="text" class="form-control" name="title" placeholder="Tiêu đề" value="<?php echo e($post->title); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Link-Liên Kết:</label>
                            <input type="text" class="form-control" name="link_to" placeholder="link-liên kết" value="<?php echo e($post->link_to); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Số Lượng Giảm Giá:</label>
                            <input type="text" class="form-control" name="discount" value="<?php echo e($post->discount); ?>"placeholder="Giảm giá">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mã Giảm Giá:</label>
                            <input type="text" class="form-control" name="discount_code" value="<?php echo e($post->discount_code); ?>"placeholder="Mã giảm giá">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Thời Hạn:</label>
                            <input type="text" class="form-control" id='example1' name="expired_date" value="<?php echo e(date("Y-m-d", strtotime($post->expired_at))); ?>" placeholder="yyyy-mm-dd">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Nội Dung Tóm Tắt:</label>
                            <textarea type="text" row="9" name="short_content" class="form-control" placeholder="Nội dung tóm tắt" required><?php echo e($post->short_content); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tin Nổi Bật:</label> &nbsp;&nbsp;&nbsp;&nbsp;
                            <?php if($post->high_light == 0): ?>
                                <label class="radio-inline"><input value="0" type="radio" name="hlight" checked>Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="hlight" >Không</label>
                            <?php else: ?>
                                <label class="radio-inline"><input value="0" type="radio" name="hlight" >Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="hlight" checked>Không</label>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mua Online:</label>  &nbsp;&nbsp;&nbsp;&nbsp;
                            <?php if($post->online == 0): ?>
                                <label class="radio-inline"><input value="0" type="radio" name="online" checked>Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="online" >Không</label>
                            <?php else: ?>
                                <label class="radio-inline"><input value="0" type="radio" name="online" >Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="online" checked>Không</label>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="email">Ảnh Hiện Tại:</label><br>
                            <img src="public/upload/image/<?php echo e($post->image); ?>" class="img-rounded" width="250px" height="175px" />
                        <br><label for="email"><?php echo e($post->image); ?></label>
                        </div>
                        <div class="form-group">
                            <label for="email">Chọn Ảnh Mới:</label>
                            <input type="file" id="fileinput" name="imgfile" class="form-control"/>
                        </div>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Cập Nhật</button>
                            <button type="reset" class="btn btn-default">Đặt Lại</button>
                            <a href="admin/post/get-all-post" class="btn btn-default">Quay Lại</a>
                        </div>
                    </form>
                
                <?php else: ?>
                
                    <form role="form" action="admin/post/edit-ads/<?php echo e($post->id); ?>" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                        <div class="form-group">
                            <label for="exampleInputEmail1">Chuyên Mục Phụ:</label>
                            <select name="subcategory" id="subcategory" class="form-control selectpicker" required>
                               <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option 
                                    <?php if( $post->fk_idSubCategory == $smenu->id): ?>
                                        <?php echo e("selected"); ?>

                                    <?php endif; ?>
                                    value="<?php echo e($smenu->id); ?>"><?php echo e($smenu->sub_cate_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tiêu Đề:</label>
                            <input type="text" class="form-control" name="title" placeholder="Tiêu đề" value="<?php echo e($post->title); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Nội Dung Tóm Tắt:</label>
                            <textarea type="text" row="9" name="short_content" class="form-control" placeholder="Nội dung tóm tắt" required><?php echo e($post->short_content); ?></textarea>
                        </div>
                         <div class="form-group">
                            <label for="exampleInputPassword1">Link-Liên Kết:</label>
                            <input type="text" class="form-control" name="link_to" placeholder="link-liên kết" value="<?php echo e($post->link_to); ?>" required>
                        </div>
                         
                        <div class="form-group">
                            <label for="exampleInputPassword1">Nội Dung Đầy Đủ:</label>
                            <textarea type="text" row="8" class="form-control ckeditor" name="full_content" placeholder="Nội dung đầy đủ"><?php echo e($post->full_content); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Tin Nổi Bật:</label> &nbsp;&nbsp;&nbsp;&nbsp;
                            <?php if($post->high_light == 0): ?>
                                <label class="radio-inline"><input value="0" type="radio" name="hlight" checked>Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="hlight" >Không</label>
                            <?php else: ?>
                                <label class="radio-inline"><input value="0" type="radio" name="hlight" >Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="hlight" checked>Không</label>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mua Online:</label>  &nbsp;&nbsp;&nbsp;&nbsp;
                            <?php if($post->online == 0): ?>
                                <label class="radio-inline"><input value="0" type="radio" name="online" checked>Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="online" >Không</label>
                            <?php else: ?>
                                <label class="radio-inline"><input value="0" type="radio" name="online" >Có</label>
                                <label class="radio-inline"><input value="1" type="radio" name="online" checked>Không</label>
                            <?php endif; ?>
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="email">Ảnh Hiện Tại:</label><br>
                            <img src="public/upload/image/<?php echo e($post->image); ?>" class="img-rounded" width="250px" height="175px" />
                        <br><label for="email"><?php echo e($post->image); ?></label>
                        </div>
                        <div class="form-group">
                            <label for="email">Chọn Ảnh Mới:</label>
                            <input type="file" id="fileinput" name="imgfile" class="form-control"/>
                        </div>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-default">Cập Nhật</button>
                            <button type="reset" class="btn btn-default">Đặt Lại</button>
                            <a href="admin/post/get-all-post" class="btn btn-default">Quay Lại</a>
                        </div>
                    </form>
                
                <?php endif; ?>
                </div>
            </div>
         </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#maincategory").change(function(){
                var idmaincategory = $(this).val()
                $.get("admin/ajax/subcategory/"+idmaincategory, function(data){
                    $("#subcategory").html(data);
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>