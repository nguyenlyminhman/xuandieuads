<div class="container">
    <hr>
    <div class="row">
        <div class="row center">
            <div class="col-sm-4">
                <h3>Xuân Diệu Ads </h3>
                <p class="text-justify"> Cung cấp thông tin về giá cả cũng như mã giảm giá các sản phẩm và các chương trình khuyến mãi nổi bật trên thị trường 
                đến từ các nhà cung cấp uy tín, giúp bạn tìm ra phẩm tốt nhất với giá ưu đãi cực HOT.</p>
            </div>
            <div class="col-sm-4">
                <h3>Hướng dẫn nhập mã giảm giá </h3>
                <p>Mã giảm giá Lazada</p>
                <p>Mã giảm giá Adayroi</p>
                <p>Mã giảm giá Tiki</p>
                <p>Mã giảm giá Lotte</p>
                <p>Mã giảm giá Sendo</p>
            </div>
            <div class="col-sm-4">
                <h3>Liên hệ </h3>
                  <div class="media">
                  <div class="media-left media-top">
                            <img src="public/images/call.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <h4>090 9900 990</h4>
                        </div>
                        <br>
                        <div class="media-left media-top">
                            <img src="public/images/fb.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <h4><a target="_blank" href="https://www.facebook.com/%C4%90i%E1%BB%87n-M%C3%A1y-M%E1%BB%8Di-Nh%C3%A0-1417775641811177/">Fanpage </a></h4>
                        </div>
                        <br>
                        <div class="media-left media-top">
                            <img src="public/images/fb.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <h4><a target="_blank" href="https://www.facebook.com/profile.php?id=100005097285904">Nguyễn Thị Xuân Diệu </a></h4>
                        </div>
                        <br>
                        <div class="media-left media-top">
                            <img src="public/images/zl.png" class="media-object">
                        </div>
                        <div class="media-body">
                            <h4>090 9900 990</h4>
                        </div>
                    </div>
                <br>
                <br>
            </div>
        </div>
    </div>
</div>