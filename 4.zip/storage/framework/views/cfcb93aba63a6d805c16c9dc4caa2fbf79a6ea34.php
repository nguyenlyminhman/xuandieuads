<?php $__env->startSection('content'); ?>
<!-- /.row -->
<br>
<div class="row">
    <div class="col-lg-12">
        <!--begin add and edit button-->
        <div class="col-lg-3">
            <button type="button" class="btn btn-primary" data-toggle="collapse" data-target="#addMenu">Thêm Hình Ảnh</button>
        </div>
        <!--end of add and edit button-->
        <!--begin notification errors-->
        <div class="col-lg-6">
            <?php if(count($errors)>0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(session('notification')): ?>
                <div class="alert alert-success">
                        <?php echo e(session('notification')); ?> <br>
                </div>
            <?php endif; ?>
        </div>
        <!--end of notification errors-->
    </div>
    <div class="col-lg-12">
        <!--add new menu item-->
        <div id="addMenu" class="collapse col-lg-6">
            <br />
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    Thêm Thêm Ảnh
                </div>
                <form action="admin/image/get-all-image" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                <br>
                    <div class="form-group">
                        <label for="email">Chọn Loại Ảnh</label>
                        <select name="fk_idcategoryimg"  class="form-control selectpicker" required>
                            <?php $__currentLoopData = $cimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cimg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cimg->id); ?>"><?php echo e($cimg->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>   
                    </div>
                    <div class="form-group">
                        <label for="email">Tiêu đề:</label>
                        <input type="text" class="form-control" name="img_title" placeHolder="Nhập tiêu đề hình ảnh" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Link-Liên Kết:</label>
                        <input type="text" class="form-control" name="link_to" placeHolder="Nhập tên menu phụ" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Hình Ảnh</label>
                        <input type="file" id="fileinput" name="imgfile" class="form-control"/>
                    </div>

                    <button type="submit" class="btn btn-default">Thêm</button>
                    <button type="reset" class="btn btn-default">Đặt Lại</button>
                    <button type="button" class="btn btn-default" data-toggle="collapse" data-target="#addMenu">Ẩn Hộp Thoại</button>
                </form>
                <br><br>
                <div class="clearfix"></div>
            </div>
            <br>
        </div>
        <!--end add new menu item-->
    </div>
    <!--danh sach menu chinh-->
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading text-center">
                <h3>Danh Sách Hình Ảnh</h3>
            </div>
            <!-- /.panel-heading -->
            <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover"  id="dataTables-example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Hình Ảnh</th>
                                <th>Link-Liên Kết</th>
                                <th>Nhóm Ảnh</th>
                                <th>Click</th>
                                <th>Lần Cuối Cập Nhật</th>
                                <th>Lựa Chọn</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($img->id); ?></td>
                                <td>
                                    <img src="./public/upload/image/<?php echo e($img->img_name); ?>" class="img-rounded" width="100px" height="75px" />
                                    <p><?php echo e($img->title); ?></p>
                                </td>
                                <td><?php echo e(substr($img->link_to, 0, 50)); ?></td>
                                <td><?php echo e($img->categoryImage->name); ?></td>
                                <td><?php echo e($img->click_counter); ?></td>
                                <td><?php echo e(date("d/m/Y", strtotime($img->updated_at))); ?></td>
                                <td>
                                <a href="admin/image/edit/<?php echo e($img->id); ?>" type="button" class="btn btn-warning">Sửa</a><br/><br/>
                                    <a  href="admin/image/delete/<?php echo e($img->id); ?>" type="button" class="btn btn-danger" 
                                        onclick='return confirm("Lưu ý: Sau khi xóa, tất cả bài viết liên quan cũng sẽ mất.\n           Có chắc muốn xóa chuyên mục này?");'>Xóa</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <!-- /.table-responsive -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!--end-danh sach menu chinh-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>