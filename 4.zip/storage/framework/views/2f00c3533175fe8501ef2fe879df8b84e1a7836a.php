<nav class="navbar navbar-inverse  navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
                aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand active" href="home">Trang Chủ</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <?php $__currentLoopData = $mmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class=<?php echo e(count($mnu->subCategory)>0 ? 'dropdown' : ''); ?>>
                        <a href="<?php echo e(count($mnu->subCategory)>0 ? 'home' : $mnu->main_cate_seolink); ?>"><span><?php echo e($mnu->main_cate_name); ?></span></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $mnu->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $snu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <li><a href="<?php echo e($mnu->id == 1 ? 'tin-khuyen-mai' : 'ma-giam-gia-voucher'); ?>/<?php echo e($snu->id); ?>/<?php echo e($snu->sub_cate_seolink); ?>.html"><?php echo e($snu->sub_cate_name); ?></a></li>
                                <li role="separator" class="divider"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <form action="timkiem" method="Post" class="navbar-form navbar-right" role="search">
                    <div class="form-group input-group">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />      
                            <input type="text" name="tukhoa" class="form-control" placeholder="Tìm kiếm..." />
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <span class="glyphicon glyphicon-search"></span>
                                </button>
                            </span>
                    </div>
                </form>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav>
