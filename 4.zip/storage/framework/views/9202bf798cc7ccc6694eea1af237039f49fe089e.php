<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Begin-new-voucher-->
<div class="container ">
    <div class="row">
        <div class="col-sm-8">
        <?php $i = 0 ?>
            <div class="row">
                <?php $__currentLoopData = $hotpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6" style="float: left">
                        <img src="public/upload/image/<?php echo e($ht->image); ?>" height="250px" width="350px">
                        <div class="text-center voucher-title">
                            <p> 
                                <a href="chi-tiet-khuyen-mai/<?php echo e($ht->id); ?>/<?php echo e($ht->title_seolink); ?>.html">
                                    <?php echo e($ht->title); ?>

                                </a>
                            </p>
                        </div>
                        <div class="row text-center">
                            <a target="_blank" href="<?php echo e($ht->link_to); ?>" type="button" class="btn btn-default">
                                <span class="glyphicon glyphicon-hand-right"> </span>
                                    Xem thêm
                                <span class="glyphicon glyphicon-hand-right"> </span>
                            </a>
                        </div>
                    </div>
                    <?php $i++; ?>
                    <?php if($i%2==0): ?>
                        </div><br><div class="row">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </div>
            
            <div class="row text-center">
                <?php echo e($hotpage->links()); ?>

            </div>
            
        </div>

        <?php echo $__env->make('layout.menuphai', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
    </div>
</div>
<!--End new voucher-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>