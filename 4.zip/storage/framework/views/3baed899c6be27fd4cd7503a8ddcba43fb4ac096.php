<div class="wthree-copyright">
    <p>© 2017 Xuan Dieu Offer. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
</div>